SELECT
  *
FROM
  t_user
WHERE
  email = ?
FOR UPDATE
