INSERT INTO
  t_login_history (`user_id`, `login`, `status`)
VALUES
  (?, ?, ?)
