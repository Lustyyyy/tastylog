UPDATE
  t_user
SET
  locked = ?
WHERE
  id = ?
