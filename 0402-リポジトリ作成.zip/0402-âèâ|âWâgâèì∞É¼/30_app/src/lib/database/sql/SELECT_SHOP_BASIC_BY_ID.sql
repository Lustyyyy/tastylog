SELECT
  *
FROM
  t_shop
WHERE
  id = ?
